#!/bin/bash

sleep 360
