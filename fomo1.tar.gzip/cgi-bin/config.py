warehouse_format = "pop"
pop_host = "pop.googlemail.com"
pop_port = 995
pop_account = "fomophobiadata@gmail.com"
pop_password = "Ih@t3Twitter"
db_host = "localhost"
db_port = 3306
db_name = "fomophobia"
db_user = "fomophobia"
db_password = "Ih@t3Twitter"
types = ["email",
    "gmail",
    "twitter",
    "sms",
    "voicemail",
    "rss",
    "reader",
    "facebook",
    "unknown",
    "all"]
logfile = "/var/log/fomo.log"
check_warehouse_delay = 120
