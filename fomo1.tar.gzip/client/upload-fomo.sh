#!/bin/bash

if [ ! "$2" ] ; then
    echo "Usage: $0 [TYPE] [IP ADDRESS]"
    echo
    exit 1
fi

ssh $2 'mkdir /usr/local/fomo/ &2>1 > /dev/null'
scp config.py.$1 $2:/usr/local/fomo/config.py
scp fomoclient.py fomoclient.init.rc $2:/usr/local/fomo/
ssh $2 'update-rc.d -f fomoclient defaults'
ssh $2 'cd /usr/local/fomo;rm fomo.msgid reallylong.txt config.pyc &2>1 > /dev/null'
ssh $2 '/etc/init.d/fomoclient restart'

exit 0

echo "Press Enter to put /etc/rc.d files in place, CTRL-C to stop here""
read var
scp fomoclient.init.rc $2:/etc/init.d/fomoclient
ssh $2 'update-rc.d fomoclient defaults'

echo "Press Enter to REBOOT client machine, CTRL-C to cancel reboot""
echo "After machine comes up, unplug and plug in the USB-to-Serial converter cable"
read var
#ssh $2 'mv /etc/udev/rules.d/40-scratch.rules /usr/local/fomo/'
ssh $2 reboot
